<?php if (is_active_sidebar('sidebar-dir')) { ?> 
				<div class="col-md-3" id="sidebar-dir">
					<?php do_action('before_sidebar'); ?> 
					<?php dynamic_sidebar('sidebar-dir'); ?> 
				</div>


<?php } ?>  
