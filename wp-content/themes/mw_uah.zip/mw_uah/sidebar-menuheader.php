<?php if (is_active_sidebar('sidebar-menuheader')) { ?> 
				
					<?php do_action('before_sidebar'); ?> 
					<?php dynamic_sidebar('sidebar-menuheader'); ?> 
			


<?php } ?>  
